const form = document.getElementById("marksForm");
const message = document.getElementById("message");
const emptyState = document.getElementById("emptyState");
const result = document.getElementById("result");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  message.textContent = "";

  const payload = {
    name: document.getElementById("studentName").value,
    marks: [
      document.getElementById("subject1").value,
      document.getElementById("subject2").value,
      document.getElementById("subject3").value
    ]
  };

  try {
    const response = await fetch("/calculate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json();

    if (!response.ok) {
      message.textContent = data.error || "Something went wrong. Please try again.";
      return;
    }

    document.getElementById("resultName").textContent = data.name;
    document.getElementById("total").textContent = data.total;
    document.getElementById("average").textContent = data.average;
    document.getElementById("grade").textContent = data.grade;
    document.getElementById("status").textContent = data.status;

    document.getElementById("subjectRows").innerHTML = data.marks
      .map((mark, index) => `<div class="subject-row"><span>Subject ${index + 1}</span><span>${mark} / 100</span></div>`)
      .join("");

    emptyState.classList.add("hidden");
    result.classList.remove("hidden");
  } catch (error) {
    message.textContent = "Could not connect to the server. Please try again.";
  }
});

document.getElementById("resetBtn").addEventListener("click", () => {
  form.reset();
  message.textContent = "";
  result.classList.add("hidden");
  emptyState.classList.remove("hidden");
});
